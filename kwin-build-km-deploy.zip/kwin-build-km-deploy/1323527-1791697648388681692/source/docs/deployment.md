# Release packaging and deployment

`kwin-mcp-deploy` is a shipped release-management CLI. Run it separately from the
stdio MCP server. It never activates services or changes the binaries used by
running clients. A reviewer chooses when to activate an installed release.

## Build and stage

```bash
kwin-mcp-deploy build /absolute/clean/checkout /absolute/new/package
```

The source must have a clean, committed HEAD. The command probes **sentry** and
**archy** concurrently, samples aggregate CPU use for one second, and selects the
lowest use eligible host (ties choose archy). Unreachable hosts or hosts lacking
Cargo, librsvg or libpipewire are skipped. **engi is excluded by default** and **benji is
not a builder**. There is no build slot limit or dependency on `dsh build`.

Use `KWIN_MCP_DEPLOY_BUILD_HOSTS=archy` to restrict eligible hosts during a
maintenance hold. The override accepts only sentry/archy/engi; it cannot enable benji builds. Use `KWIN_MCP_DEPLOY_BUILD_ROOT=/tmp/kwin-build-your-name`
to put the unique run directories on another filesystem. Check storage and memory
before selecting a tmpfs root. For example:

```bash
KWIN_MCP_DEPLOY_BUILD_HOSTS=archy \
KWIN_MCP_DEPLOY_BUILD_ROOT=/tmp/kwin-build-review-248 \
CARGO_BUILD_JOBS=2 kwin-mcp-deploy build /absolute/checkout /absolute/new/package
```

When host policy explicitly permits engi builds, select
`KWIN_MCP_DEPLOY_BUILD_HOSTS='engi archy'` and a private home build root, such as
`/home/nate/work/kwin-build-review-248`. Engi builds always invoke Cargo at
`nice -n 19`; compiler children inherit that priority. Maintenance holds are
expressed by the operator's host list. Choose jobs and storage using current
aggregate memory and disk availability, and keep one own compile active.

A Git bundle transfers the exact commit without requiring it to be pushed.
Each run owns `~/builds/kwin-mcp-deploy/<unique-id>/source`, its separate `target`,
and `build.log`. Builds use `cargo build --locked --release --bins` and the
caller's `CARGO_BUILD_JOBS` when set (positive integer), or the builder's
normal Cargo parallelism otherwise. Source, target and logs remain on the builder
for review; remove only that run directory when its evidence is no longer needed.
The command returns the log and packages all four binaries with the units, this
guide, source identity and SHA256SUMS. It does not install anything.

For a separately compiled release, use:

```bash
kwin-mcp-deploy package /absolute/artifacts /absolute/new/package
```

This checks regular executable ELF64 files (symlink artifacts are rejected) and records that artifact provenance needs separate
verification. Packaging preserves the input binaries. Missing files and existing
package destinations fail; an incomplete package is retained for diagnosis and
cannot be installed until its manifest is complete.

## Inspect without installing

```bash
kwin-mcp-deploy inspect /absolute/package
```

This verifies the fixed checksum list and prints release identity. It performs no
remote operation and writes no files, so reviewers can inspect a staged package
before deciding whether to install it.

## Explicit installation

Create the destination's parent directory first. Install into a **new** release
directory on one explicitly named host:

```bash
kwin-mcp-deploy install /absolute/package engi /home/nate/releases/kwin-mcp-review-248
kwin-mcp-deploy install /absolute/package archy /home/nate/releases/kwin-mcp-review-248
kwin-mcp-deploy install /absolute/package benji /home/nate/releases/kwin-mcp-review-248
```

Allowed destinations are engi, archy and benji. An unreachable benji is reported
and skipped successfully; other connectivity failures fail the operation. There
is no implicit fleet install. Local-host builds and installations use direct commands and filesystem copies;\nan SSH listener on the local host is not needed. Remote SSH uses BatchMode and a five second connection
timeout; it never asks for credentials. Release paths must be absolute and use
letters, digits, `_`, `-` and `.` in each component, without `.` or `..` components.

The CLI checks the local fixed file manifest, transfers into a private sibling
staging directory, checks the remote checksums, and renames the whole directory
without replacing an existing release. Failed transfers remove their own staging
directory. Existing releases, live symlinks and services are never changed. This
allows review and removal of a private release without affecting production.
Inspect `release.txt` and `SHA256SUMS` before selecting a release in your client's
stdio configuration. Hosts must have compatible architecture, glibc and runtime
libraries; checksums do not establish ABI compatibility. Run a real stdio session
on each installation host before activation. Stop every verification session.

## Optional OAuth gateway and tunnel units

Packages ship templates under `systemd/`. They are **not enabled or started** by
the CLI. Copy reviewed templates to `~/.config/systemd/user/` when intentionally
configuring a gateway, then run `systemctl --user daemon-reload`. Both units follow
`graphical-session.target`; the tunnel binds to `kwin-mcp-gateway.service` and
stops when that gateway stops. Their restart delay is five seconds.

### Stage current-server configuration

```bash
kwin-mcp-deploy gateway-config /absolute/installed/release /absolute/new/config
```

This creates `mcp-gateway/servers.toml` and `env.example` in a new directory. It
selects that release's `bin/kwin-mcp` directly with display dimensions and
`--autoclean`, and disables accidental source reload by setting `KWIN_MCP_REPO`
to a nonexistent source directory under the release. Existing configuration is
rejected. No live configuration is changed and no gateway is started.

After review, the unit expects this staged configuration at
`~/.config/kwin-mcp-gateway/`, with a private `env` file (mode 0600) based on the
example. The example has an empty key so it cannot start an authenticated gateway
until configured. Set `MCP_GATEWAY_KEY` to a private random key of at least 32
characters, `MCP_GATEWAY_PUBLIC_URL` to the public HTTPS origin, and
`MCP_GATEWAY_LISTEN` to a loopback address such as `127.0.0.1:8097`. Keep OAuth
credentials out of the repository and release package.

### Gateway dependency and provenance

The executable prerequisite is **`~/.local/bin/mcp-gateway`**, not the obsolete
`kwin-mcp-gateway` scratch script. The inspected implementation is the
`mcp-gateway` package, version **0.1.0**, in the Rust services source: gateway logic
commit `5101251bed9e94e96493b00019b56c089c2d069c` (2026-10-01), preserved in checkout
`0de37e411591712018345331e5495a55eb069d07`. That archived checkout originates from
`sentry:/data/src/rust-services`; the related repository is
[nm-z/rust-services](https://github.com/nm-z/rust-services). At integration time,
GitHub's default branch does not contain this package and the preserved checkout
commit is unavailable through GitHub. **A maintained published gateway dependency
is still an integration review gate.** The installed ELF alone cannot establish
its exact source revision. These templates do not implement OAuth themselves.

The inspected API reads `MCP_GATEWAY_KEY`, `MCP_GATEWAY_PUBLIC_URL` and
`MCP_GATEWAY_LISTEN`; reads `XDG_CONFIG_HOME/mcp-gateway/servers.toml`; and launches
`[servers.kwin]`'s `command`, `args` and optional `env` directly over stdio. The
route is `/kwin/mcp`. Gateway state is kept under
`XDG_STATE_HOME/mcp-gateway/`. The shipped unit sets dedicated config/state roots
and checks for the executable, private env file and server configuration.

The old live `mcp-gateway.service` may serve multiple backends. Migration requires
reviewing and preserving those entries, selecting the current server executable,
and deliberately retiring the obsolete unit only after verification. Do not
start both gateways on the same listen address. The CLI never edits the old
`~/.config/mcp-gateway/servers.toml`, copies existing secrets, disables a unit, or
switches a live client. To roll back a future operator migration, restore the
previous reviewed configuration/unit selection and keep its old release until
acceptance is complete.

Install `/usr/bin/cloudflared` separately and configure
`~/.cloudflared/kwin-mcp.yml` with your tunnel identity and ingress for your OAuth
gateway's loopback address. Keep credentials private. The shipped tunnel template
does not hardcode a domain or tunnel token. Review both configurations and verify
authentication before exposing the gateway. Service enablement, tunnel creation,
live activation and rollback are operator decisions.

`kwin-mcp-shim` from the scratch script is not built by this repository and is not
part of a release package. Deploy any external shim through its owning project.
